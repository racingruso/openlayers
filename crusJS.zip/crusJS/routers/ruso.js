const express = require('express')
const router = express.Router()
const RusoRes = require('../models/ruso')


router.get('/', async(req,res) => {
try{
    const ruso= await RusoRes.find()
    res.json(ruso)
}catch(err)
{
    res.send('Error'+err)
}
})
router.post('/',async(req,res) =>
{
    const ruso =new RusoRes({
        name: req.body.name,
        address: req.body.address,
        image: req.body.image
    })
    try
    {
        const ru=await ruso.save() 
        res.json(ru)
    }catch(error)
    {
        res.send('Error'+error)
    }
})
module.exports = router