const express = require('express')
const mongoose = require('mongoose')
const url = 'mongodb://localhost/admin'
const app= express()

mongoose.connect(url,{useNewUrlParser:true})
const con = mongoose.connection


con.on('open',() =>{

    console.log('Connected...')
})

app.use(express.json())

const rusoRouter = require('./routers/ruso')
app.use('/ruso',rusoRouter)
app.listen(9000,() =>{
    console.log('server started')
})