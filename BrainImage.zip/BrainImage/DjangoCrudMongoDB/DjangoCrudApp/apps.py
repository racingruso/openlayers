from django.apps import AppConfig


class DjangocrudappConfig(AppConfig):
    name = 'DjangoCrudApp'
